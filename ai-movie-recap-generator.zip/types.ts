export enum UserRole {
  USER = 'USER',
  ADMIN = 'ADMIN'
}

export enum VideoRatio {
  PORTRAIT = '9:16',
  LANDSCAPE = '16:9'
}

export interface User {
  id: string;
  email: string;
  role: UserRole;
  isVip: boolean;
  generatedCount: number;
  vipCodeUsed?: string;
  createdAt: number;
}

export interface VipCode {
  code: string;
  isUsed: boolean;
  usedBy?: string; // User ID
  createdAt: number;
}

export interface AdminSettings {
  contactLink: string;
}

export interface VideoProject {
  id: string;
  userId: string;
  originalUrl: string;
  script: string;
  audioUrl?: string; // Blob URL
  imageUrls: string[];
  ratio: VideoRatio;
  status: 'processing' | 'completed' | 'failed';
  createdAt: number;
}

export interface AuthResponse {
  user: User;
  token: string;
}