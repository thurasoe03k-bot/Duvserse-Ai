import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import AdminPanel from './components/AdminPanel';
import Dashboard from './components/Dashboard';
import { StorageService } from './services/storage';
import { User, UserRole } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  
  // Auth Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    const currentUser = StorageService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    const u = StorageService.login(email, password);
    if (u) {
      setUser(u);
    } else {
      setAuthError('Invalid email or password');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      const u = StorageService.register(email, password);
      setUser(u);
    } catch (err: any) {
      setAuthError(err.message);
    }
  };

  const handleLogout = () => {
    StorageService.logout();
    setUser(null);
    setEmail('');
    setPassword('');
  };

  const handleRefreshUser = () => {
    const u = StorageService.getCurrentUser();
    if (u) setUser(u);
  };

  // --- View Logic ---

  if (user) {
    return (
      <Layout>
        {user.role === UserRole.ADMIN ? (
          <AdminPanel onLogout={handleLogout} />
        ) : (
          <Dashboard user={user} onLogout={handleLogout} onRefreshUser={handleRefreshUser} />
        )}
      </Layout>
    );
  }

  // Login / Signup Screen
  return (
    <Layout>
      <div className="flex flex-col h-full justify-center p-8 bg-slate-900 text-white">
        <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold text-amber-500 mb-2">MovieRecap AI</h1>
            <p className="text-slate-400">Transform any video into a viral recap.</p>
        </div>

        <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1 uppercase">Email</label>
            <input 
              type="email" 
              required
              className="w-full bg-slate-800 border border-slate-700 rounded p-3 focus:border-amber-500 outline-none transition-colors"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 mb-1 uppercase">Password</label>
            <input 
              type="password" 
              required
              className="w-full bg-slate-800 border border-slate-700 rounded p-3 focus:border-amber-500 outline-none transition-colors"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
          
          {authError && <p className="text-red-500 text-sm text-center bg-red-900/20 p-2 rounded">{authError}</p>}

          <button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-3 rounded-lg transition-transform active:scale-95">
            {isRegistering ? 'Create Account' : 'Login'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button 
            onClick={() => setIsRegistering(!isRegistering)}
            className="text-sm text-slate-500 hover:text-amber-400 underline"
          >
            {isRegistering ? 'Already have an account? Login' : 'No account? Sign up free'}
          </button>
        </div>
      </div>
    </Layout>
  );
};

export default App;