import React, { useState } from 'react';
import { User, VideoRatio, VideoProject } from '../types';
import { StorageService } from '../services/storage';
import { generateRecapScript, generateImagePrompts, generateSpeech } from '../services/gemini';
import { LogOut, Crown, Film, AlertCircle } from 'lucide-react';

interface DashboardProps {
    user: User;
    onLogout: () => void;
    onRefreshUser: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout, onRefreshUser }) => {
    // UI State
    const [view, setView] = useState<'create' | 'player' | 'vip'>('create');
    const [videoUrl, setVideoUrl] = useState('');
    const [language, setLanguage] = useState('English');
    const [ratio, setRatio] = useState<VideoRatio>(VideoRatio.PORTRAIT);
    const [voice, setVoice] = useState('Puck'); // Default male-ish
    const [loadingStep, setLoadingStep] = useState<string | null>(null);
    const [generatedVideo, setGeneratedVideo] = useState<VideoProject | null>(null);
    const [vipCodeInput, setVipCodeInput] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const adminLink = StorageService.getSettings().contactLink;
    const isFreeLimitReached = !user.isVip && user.generatedCount >= 1;

    const voices = [
        { name: 'Puck', label: 'Male - Storyteller', lang: 'English' },
        { name: 'Kore', label: 'Female - Calm', lang: 'English' },
        // VIP Voices
        { name: 'Fenrir', label: 'Male - Deep (VIP)', lang: 'English', vip: true },
        { name: 'Charon', label: 'Male - Fast (VIP)', lang: 'English', vip: true },
        { name: 'Aoede', label: 'Female - Soft (VIP)', lang: 'English', vip: true },
    ];

    const handleGenerate = async () => {
        if (isFreeLimitReached) {
            setView('vip');
            return;
        }

        if (!videoUrl) return;
        setErrorMsg('');
        setLoadingStep('Analyzing video...');

        try {
            // 1. Generate Script
            const script = await generateRecapScript(videoUrl, language);
            setLoadingStep('Writing script...');
            
            // 2. Generate Voice
            // Note: Since 'Myanmar' isn't natively supported by Gemini TTS yet, we fall back to English engine 
            // reading translated text or prompt user. For this demo, we assume the user selected English or accepts the limitation.
            setLoadingStep('Synthesizing voice...');
            const audioUrl = await generateSpeech(script, voice);

            // 3. Generate Visuals (Prompts)
            setLoadingStep('Generating visuals...');
            const imagePrompts = await generateImagePrompts(script);
            
            // Map prompts to placeholder images for demo (In real prod, use Imagen)
            // Using picsum with specific seeds to keep it consistent
            const imageUrls = imagePrompts.map((_, i) => `https://picsum.photos/seed/${Math.random()}/${ratio === VideoRatio.PORTRAIT ? '720/1280' : '1280/720'}`);

            // 4. Finalize
            setLoadingStep('Rendering video...');
            // Simulate processing time
            await new Promise(r => setTimeout(r, 1500));

            const newVideo: VideoProject = {
                id: crypto.randomUUID(),
                userId: user.id,
                originalUrl: videoUrl,
                script,
                audioUrl,
                imageUrls,
                ratio,
                status: 'completed',
                createdAt: Date.now()
            };

            StorageService.saveVideo(newVideo);
            onRefreshUser(); // Update count
            setGeneratedVideo(newVideo);
            setLoadingStep(null);
            setView('player');

        } catch (err: any) {
            setLoadingStep(null);
            setErrorMsg(err.message || 'Generation failed. Please try again.');
        }
    };

    const handleRedeemVip = () => {
        const success = StorageService.redeemVipCode(user.id, vipCodeInput.trim());
        if (success) {
            alert('VIP Activated Successfully!');
            onRefreshUser();
            setView('create');
        } else {
            setErrorMsg('Invalid or used VIP code.');
        }
    };

    // --- Render Components ---

    if (view === 'player' && generatedVideo) {
        return (
            <div className="flex flex-col h-full bg-black">
                 <div className="p-4 flex justify-between items-center bg-slate-900">
                    <button onClick={() => setView('create')} className="text-white text-sm">← Back</button>
                    <span className="text-amber-500 font-bold text-sm">Result</span>
                </div>
                
                {/* Simulated Video Player */}
                <div className={`flex-1 relative flex items-center justify-center overflow-hidden ${generatedVideo.ratio === VideoRatio.PORTRAIT ? 'w-full' : 'w-full bg-black'}`}>
                    <div className="relative w-full h-full">
                         {/* We just show the first image and play audio for the demo */}
                         <img src={generatedVideo.imageUrls[0]} className="w-full h-full object-cover animate-pulse" alt="Recap Visual" />
                         
                         <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                             <div className="text-center p-6">
                                 <h3 className="text-white font-bold text-xl mb-4 drop-shadow-md">Recap Ready</h3>
                                 <audio controls src={generatedVideo.audioUrl} className="mx-auto" autoPlay />
                                 <p className="text-white/80 text-xs mt-4">
                                     *Demo: Audio generated by Gemini TTS. Visuals are placeholders.*
                                 </p>
                                 {!user.isVip && (
                                     <div className="absolute top-4 right-4 bg-black/50 text-white/50 text-xs px-2 py-1">WATERMARK</div>
                                 )}
                             </div>
                         </div>
                    </div>
                </div>

                <div className="p-6 bg-slate-900">
                    <h4 className="text-white font-bold mb-2">Script:</h4>
                    <p className="text-slate-400 text-xs leading-relaxed h-32 overflow-y-auto p-2 bg-slate-800 rounded">
                        {generatedVideo.script}
                    </p>
                    <button onClick={() => setView('create')} className="w-full mt-4 bg-amber-500 text-black font-bold py-3 rounded-lg">
                        Create Another
                    </button>
                </div>
            </div>
        );
    }

    if (view === 'vip') {
        return (
            <div className="p-6 flex flex-col h-full items-center justify-center text-center space-y-6">
                <Crown className="w-16 h-16 text-amber-400" />
                <h2 className="text-2xl font-bold text-white">Upgrade to VIP</h2>
                <p className="text-slate-400 text-sm">
                    You have used your free generation. Unlock unlimited videos, premium voices, and remove watermarks.
                </p>
                
                <div className="w-full space-y-2">
                    <input 
                        type="text" 
                        placeholder="Enter VIP Code" 
                        value={vipCodeInput}
                        onChange={(e) => setVipCodeInput(e.target.value)}
                        className="w-full p-3 bg-slate-800 text-white rounded border border-slate-700 text-center uppercase"
                    />
                    {errorMsg && <p className="text-red-500 text-xs">{errorMsg}</p>}
                    <button onClick={handleRedeemVip} className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-3 rounded-lg">
                        Activate VIP
                    </button>
                </div>

                <div className="w-full border-t border-slate-800 pt-4">
                    <p className="text-slate-500 text-xs mb-2">Don't have a code?</p>
                    <a 
                        href={adminLink} 
                        target="_blank" 
                        rel="noreferrer"
                        className="block w-full bg-blue-600 text-white font-bold py-3 rounded-lg"
                    >
                        Contact Admin to Buy
                    </a>
                </div>
                <button onClick={() => setView('create')} className="text-slate-500 text-sm underline">Back to Home</button>
            </div>
        );
    }

    // Default: Create View
    return (
        <div className="flex flex-col h-full relative">
             {loadingStep && (
                 <div className="absolute inset-0 bg-black/90 z-50 flex flex-col items-center justify-center text-center p-6">
                     <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                     <p className="text-amber-500 font-bold animate-pulse">{loadingStep}</p>
                     <p className="text-slate-500 text-xs mt-2">Do not close this window.</p>
                 </div>
             )}

            <div className="flex justify-between items-center p-4 bg-slate-900 border-b border-slate-800">
                <div className="flex items-center gap-2">
                    <Film className="text-amber-500 w-5 h-5" />
                    <h1 className="font-bold text-white">MovieRecap AI</h1>
                </div>
                <div className="flex items-center gap-3">
                    {user.isVip && <span className="bg-amber-500/20 text-amber-400 text-xs px-2 py-1 rounded font-bold border border-amber-500/50">VIP</span>}
                    <button onClick={onLogout}><LogOut className="text-slate-400 w-5 h-5" /></button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                
                {isFreeLimitReached && (
                    <div onClick={() => setView('vip')} className="bg-amber-900/30 border border-amber-500/30 p-3 rounded-lg flex items-center gap-3 cursor-pointer">
                        <AlertCircle className="text-amber-500 w-5 h-5 shrink-0" />
                        <div className="text-left">
                            <p className="text-amber-200 text-sm font-bold">Free Limit Reached</p>
                            <p className="text-amber-200/60 text-xs">Tap to upgrade to VIP</p>
                        </div>
                    </div>
                )}

                {/* Input Section */}
                <div className="space-y-4">
                    <div>
                        <label className="block text-slate-400 text-xs mb-1 uppercase font-bold tracking-wider">Video Link</label>
                        <input 
                            type="text" 
                            placeholder="Paste YouTube / TikTok / FB link"
                            value={videoUrl}
                            onChange={(e) => setVideoUrl(e.target.value)}
                            className="w-full bg-slate-800 text-white p-3 rounded-lg border border-slate-700 focus:border-amber-500 outline-none transition-colors"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-slate-400 text-xs mb-1 uppercase font-bold tracking-wider">Aspect Ratio</label>
                            <div className="flex bg-slate-800 rounded-lg p-1">
                                <button 
                                    onClick={() => setRatio(VideoRatio.PORTRAIT)}
                                    className={`flex-1 py-2 text-xs rounded ${ratio === VideoRatio.PORTRAIT ? 'bg-amber-600 text-white shadow' : 'text-slate-400'}`}
                                >
                                    9:16
                                </button>
                                <button 
                                    onClick={() => setRatio(VideoRatio.LANDSCAPE)}
                                    className={`flex-1 py-2 text-xs rounded ${ratio === VideoRatio.LANDSCAPE ? 'bg-amber-600 text-white shadow' : 'text-slate-400'}`}
                                >
                                    16:9
                                </button>
                            </div>
                         </div>
                         <div>
                            <label className="block text-slate-400 text-xs mb-1 uppercase font-bold tracking-wider">Language</label>
                            <select 
                                value={language}
                                onChange={(e) => setLanguage(e.target.value)}
                                className="w-full bg-slate-800 text-white p-3 rounded-lg border border-slate-700 outline-none text-sm"
                            >
                                <option value="English">English</option>
                                <option value="Burmese">Burmese (Myanmar)</option>
                            </select>
                         </div>
                    </div>

                    <div>
                        <label className="block text-slate-400 text-xs mb-1 uppercase font-bold tracking-wider">Voice Actor</label>
                        <div className="grid grid-cols-1 gap-2">
                            {voices.map(v => (
                                <button
                                    key={v.name}
                                    onClick={() => {
                                        if (v.vip && !user.isVip) {
                                            setView('vip');
                                        } else {
                                            setVoice(v.name);
                                        }
                                    }}
                                    className={`flex items-center justify-between p-3 rounded-lg border ${voice === v.name ? 'border-amber-500 bg-amber-500/10' : 'border-slate-800 bg-slate-800'} text-left transition-all`}
                                >
                                    <div className="flex flex-col">
                                        <span className={`text-sm font-semibold ${voice === v.name ? 'text-amber-400' : 'text-slate-300'}`}>{v.name}</span>
                                        <span className="text-xs text-slate-500">{v.label}</span>
                                    </div>
                                    {v.vip && !user.isVip && <Crown className="w-4 h-4 text-amber-500" />}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="p-4 bg-slate-900 border-t border-slate-800">
                {errorMsg && <p className="text-red-500 text-xs mb-2 text-center">{errorMsg}</p>}
                <button 
                    onClick={handleGenerate}
                    disabled={isFreeLimitReached}
                    className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg ${isFreeLimitReached ? 'bg-slate-700 text-slate-500 cursor-not-allowed' : 'bg-gradient-to-r from-amber-500 to-orange-600 text-white'}`}
                >
                    {isFreeLimitReached ? 'Limit Reached' : 'Generate Video'}
                </button>
            </div>
        </div>
    );
};

export default Dashboard;