import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen w-full bg-slate-950 flex justify-center items-start">
      <div className="w-full max-w-[480px] min-h-screen bg-slate-900 shadow-2xl relative flex flex-col border-x border-slate-800">
        {children}
      </div>
    </div>
  );
};

export default Layout;