import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storage';
import { User, VipCode } from '../types';

const AdminPanel: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'codes' | 'settings'>('codes');
  const [users, setUsers] = useState<User[]>([]);
  const [codes, setCodes] = useState<VipCode[]>([]);
  const [contactLink, setContactLink] = useState('');
  const [totalVideos, setTotalVideos] = useState(0);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setUsers(StorageService.getAllUsers());
    setCodes(StorageService.getVipCodes());
    setContactLink(StorageService.getSettings().contactLink);
    setTotalVideos(StorageService.getTotalVideosCount());
  };

  const handleGenerateCode = () => {
    StorageService.generateVipCode();
    refreshData();
  };

  const handleSaveSettings = () => {
    StorageService.updateSettings({ contactLink });
    alert('Settings Saved');
  };

  const toggleVipStatus = (user: User) => {
      const updated = { ...user, isVip: !user.isVip };
      StorageService.updateUser(updated);
      refreshData();
  };

  return (
    <div className="p-4 flex flex-col h-full text-slate-100">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold text-amber-500">Admin Panel</h1>
        <button onClick={onLogout} className="text-sm text-slate-400">Logout</button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-slate-800 p-3 rounded-lg text-center">
            <span className="block text-2xl font-bold">{users.length}</span>
            <span className="text-xs text-slate-400">Total Users</span>
        </div>
        <div className="bg-slate-800 p-3 rounded-lg text-center">
            <span className="block text-2xl font-bold">{totalVideos}</span>
            <span className="text-xs text-slate-400">Videos Gen</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 mb-4 border-b border-slate-700 pb-2">
        <button onClick={() => setActiveTab('codes')} className={`px-3 py-1 text-sm rounded ${activeTab === 'codes' ? 'bg-amber-600 text-white' : 'text-slate-400'}`}>VIP Codes</button>
        <button onClick={() => setActiveTab('users')} className={`px-3 py-1 text-sm rounded ${activeTab === 'users' ? 'bg-amber-600 text-white' : 'text-slate-400'}`}>Users</button>
        <button onClick={() => setActiveTab('settings')} className={`px-3 py-1 text-sm rounded ${activeTab === 'settings' ? 'bg-amber-600 text-white' : 'text-slate-400'}`}>Settings</button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {activeTab === 'codes' && (
            <div className="space-y-3">
                <button 
                    onClick={handleGenerateCode}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm font-semibold mb-2"
                >
                    + Generate New Lifetime Code
                </button>
                {codes.length === 0 && <p className="text-center text-slate-500 text-sm">No codes generated.</p>}
                {codes.slice().reverse().map((c) => (
                    <div key={c.code} className="bg-slate-800 p-3 rounded flex justify-between items-center text-sm">
                        <span className="font-mono text-amber-400 select-all">{c.code}</span>
                        <span className={`px-2 py-0.5 rounded text-xs ${c.isUsed ? 'bg-red-900 text-red-200' : 'bg-green-900 text-green-200'}`}>
                            {c.isUsed ? `Used` : 'Active'}
                        </span>
                    </div>
                ))}
            </div>
        )}

        {activeTab === 'users' && (
            <div className="space-y-3">
                {users.map(u => (
                    <div key={u.id} className="bg-slate-800 p-3 rounded flex flex-col gap-2 text-sm">
                        <div className="flex justify-between">
                            <span className="font-semibold">{u.email}</span>
                            <span className="text-xs text-slate-500">{u.role}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-xs text-slate-400">Gen: {u.generatedCount}</span>
                            <button 
                                onClick={() => toggleVipStatus(u)}
                                className={`text-xs px-2 py-1 rounded ${u.isVip ? 'bg-amber-600 text-white' : 'bg-slate-700 text-slate-300'}`}
                            >
                                {u.isVip ? 'Revoke VIP' : 'Grant VIP'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        )}

        {activeTab === 'settings' && (
            <div className="space-y-4">
                <div>
                    <label className="block text-xs text-slate-400 mb-1">Admin Contact Link</label>
                    <input 
                        type="text" 
                        value={contactLink}
                        onChange={(e) => setContactLink(e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white text-sm"
                        placeholder="https://t.me/..."
                    />
                </div>
                <button 
                    onClick={handleSaveSettings}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold"
                >
                    Save Settings
                </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;