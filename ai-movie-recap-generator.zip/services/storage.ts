import { User, UserRole, VipCode, AdminSettings, VideoProject } from '../types';

const USERS_KEY = 'amr_users';
const VIP_KEY = 'amr_vip_codes';
const SETTINGS_KEY = 'amr_settings';
const VIDEOS_KEY = 'amr_videos';
const SESSION_KEY = 'amr_session';

// Initialize Default Data
const init = () => {
  if (!localStorage.getItem(SETTINGS_KEY)) {
    const defaultSettings: AdminSettings = { contactLink: 'https://t.me/admin_support' };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(defaultSettings));
  }
  if (!localStorage.getItem(VIP_KEY)) {
    localStorage.setItem(VIP_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(USERS_KEY)) {
    localStorage.setItem(USERS_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(VIDEOS_KEY)) {
    localStorage.setItem(VIDEOS_KEY, JSON.stringify([]));
  }
};

init();

export const StorageService = {
  // --- Auth & User ---
  login: (email: string, passwordHash: string): User | null => {
    // Admin Hardcoded Check
    if (email === 'admin@gmail.com' && passwordHash === 'taunggyi') {
      const adminUser: User = {
        id: 'admin-001',
        email,
        role: UserRole.ADMIN,
        isVip: true,
        generatedCount: 0,
        createdAt: Date.now()
      };
      localStorage.setItem(SESSION_KEY, JSON.stringify(adminUser));
      return adminUser;
    }

    const users: User[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    // In a real app, password checking would be here (and hashed)
    // For this demo, we assume the caller handles "password" logic or we simplify
    const user = users.find(u => u.email === email); 
    // basic password check simulation (using hash string equality)
    // NOTE: For this demo, we are skipping actual hash comparison for simplicity 
    // unless we registered with it.
    
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    }
    return null;
  },

  register: (email: string, passwordHash: string): User => {
    const users: User[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    if (users.find(u => u.email === email)) {
      throw new Error('User already exists');
    }
    const newUser: User = {
      id: crypto.randomUUID(),
      email,
      role: UserRole.USER,
      isVip: false,
      generatedCount: 0,
      createdAt: Date.now()
    };
    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
    return newUser;
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  },

  getCurrentUser: (): User | null => {
    const u = localStorage.getItem(SESSION_KEY);
    return u ? JSON.parse(u) : null;
  },

  updateUser: (user: User) => {
    const users: User[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const index = users.findIndex(u => u.id === user.id);
    if (index !== -1) {
      users[index] = user;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      // Update session if it's the current user
      const current = JSON.parse(localStorage.getItem(SESSION_KEY) || '{}');
      if (current.id === user.id) {
        localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      }
    }
  },

  getAllUsers: (): User[] => {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  },

  // --- VIP System ---
  generateVipCode: (): VipCode => {
    const codes: VipCode[] = JSON.parse(localStorage.getItem(VIP_KEY) || '[]');
    const newCode: VipCode = {
      code: 'VIP-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      isUsed: false,
      createdAt: Date.now()
    };
    codes.push(newCode);
    localStorage.setItem(VIP_KEY, JSON.stringify(codes));
    return newCode;
  },

  getVipCodes: (): VipCode[] => {
    return JSON.parse(localStorage.getItem(VIP_KEY) || '[]');
  },

  redeemVipCode: (userId: string, codeStr: string): boolean => {
    const codes: VipCode[] = JSON.parse(localStorage.getItem(VIP_KEY) || '[]');
    const codeIndex = codes.findIndex(c => c.code === codeStr && !c.isUsed);

    if (codeIndex === -1) return false;

    // Update Code
    codes[codeIndex].isUsed = true;
    codes[codeIndex].usedBy = userId;
    localStorage.setItem(VIP_KEY, JSON.stringify(codes));

    // Update User
    const users: User[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex !== -1) {
      users[userIndex].isVip = true;
      users[userIndex].vipCodeUsed = codeStr;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      
      // Update Session
      const session = JSON.parse(localStorage.getItem(SESSION_KEY) || '{}');
      if (session.id === userId) {
        session.isVip = true;
        session.vipCodeUsed = codeStr;
        localStorage.setItem(SESSION_KEY, JSON.stringify(session));
      }
    }
    return true;
  },

  // --- Admin Settings ---
  getSettings: (): AdminSettings => {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
  },

  updateSettings: (settings: AdminSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  },

  // --- Videos ---
  saveVideo: (video: VideoProject) => {
    const videos: VideoProject[] = JSON.parse(localStorage.getItem(VIDEOS_KEY) || '[]');
    videos.push(video);
    localStorage.setItem(VIDEOS_KEY, JSON.stringify(videos));
    
    // Increment user count
    const users: User[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const uIdx = users.findIndex(u => u.id === video.userId);
    if (uIdx !== -1) {
      users[uIdx].generatedCount += 1;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      // Update session if needed
      const current = JSON.parse(localStorage.getItem(SESSION_KEY) || '{}');
      if (current.id === video.userId) {
        current.generatedCount += 1;
        localStorage.setItem(SESSION_KEY, JSON.stringify(current));
      }
    }
  },
  
  getTotalVideosCount: (): number => {
      const videos: VideoProject[] = JSON.parse(localStorage.getItem(VIDEOS_KEY) || '[]');
      return videos.length;
  }
};