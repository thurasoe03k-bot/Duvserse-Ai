import { GoogleGenAI, Modality } from "@google/genai";

const getClient = () => {
    // Using environment variable as per instructions
    const apiKey = process.env.API_KEY || ''; 
    if (!apiKey) {
        console.error("API_KEY is missing from environment");
    }
    return new GoogleGenAI({ apiKey });
};

export const generateRecapScript = async (videoUrl: string, language: string): Promise<string> => {
    const ai = getClient();
    try {
        const prompt = `
        Create a short, engaging movie recap script for the video at this URL: ${videoUrl}.
        The script should be a summary, not a verbatim transcript.
        Style: Storyteller, engaging, dramatic.
        Language: ${language}.
        Keep it under 150 words.
        Plain text only, no markdown formatting.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview', // Efficient model for text
            contents: prompt,
        });

        return response.text || "Could not generate script.";
    } catch (error) {
        console.error("Gemini Script Error:", error);
        throw new Error("Failed to generate script. Please check the URL and try again.");
    }
};

export const generateImagePrompts = async (script: string): Promise<string[]> => {
    const ai = getClient();
    try {
        const prompt = `
        Based on this script: "${script}"
        Generate 5 visual scene descriptions that match the narrative.
        Return ONLY a JSON array of strings. No markdown.
        Example: ["A dark forest at night", "A hero holding a sword"]
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: { responseMimeType: 'application/json' }
        });

        const text = response.text || '[]';
        return JSON.parse(text);
    } catch (error) {
        console.error("Gemini Image Prompt Error", error);
        // Fallback prompts if AI fails
        return ["Cinematic movie scene", "Dramatic close up", "Action sequence", "Mystery background", "Epic landscape"];
    }
};

export const generateSpeech = async (text: string, voiceName: string): Promise<string> => {
    const ai = getClient();
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voiceName }, // e.g., 'Kore', 'Fenrir'
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        
        if (!base64Audio) throw new Error("No audio data returned");

        // Convert base64 to Blob URL
        const binaryString = atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: 'audio/mp3' });
        return URL.createObjectURL(blob);

    } catch (error) {
        console.error("Gemini TTS Error:", error);
        throw new Error("Failed to generate voice audio.");
    }
};